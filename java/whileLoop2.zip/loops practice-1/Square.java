public class Square{

public static void main(String[] args){

int i=1, square=2;

while(i<=20){

System.out.println("square of" +i+"="+i*i);
i++;

}
}
}