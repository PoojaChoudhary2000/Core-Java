public class Cube{

public static void main(String[] args){

int i=1;

while(i<=20){

System.out.println("cube of  "  +i+ " = " + i*i*i);
i++;
}

}

}