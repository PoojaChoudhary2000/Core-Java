public class Program7{
public static void main(String[] args){

int a = Integer.parseInt(args[0]);
int b = Integer.parseInt(args[1]);

System.out.println("Addition : "+(a+b));
System.out.println("Multiplication : "+(a*b));
System.out.println("Substraction : "+(a-b));
System.out.println("Division : "+(a/b));
}
}