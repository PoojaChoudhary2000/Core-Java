public class Program2{
public static void main(String[] args){

int rem;
int num=Integer.parseInt(args[0]);
rem=num%10;

System.out.println(rem);
}
}