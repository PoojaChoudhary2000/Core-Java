public class Program3{
public static void main(String[] args){

int num=Integer.parseInt(args[0]);
if(num%2==0){
System.out.println("Given num is even");
}
else{
System.out.println("Given num is odd");
}
}
}