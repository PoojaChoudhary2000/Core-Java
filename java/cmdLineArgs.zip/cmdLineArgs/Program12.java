public class Program12{
public static void main(String[] args){

int num = Integer.parseInt(args[0]);
System.out.println(Math.cbrt(num));
}
}