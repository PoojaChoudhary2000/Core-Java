public class TableOfTwo{

public static void main(String[] args){

int i=1, n=3;

while(i<=10){

System.out.println(n+" x "+i+" = "+i*n);
i++;
}
}
}