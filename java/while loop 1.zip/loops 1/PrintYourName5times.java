public class PrintYourName5times{

public static void main(String[] args){

System.out.println("hello");

int i=0;

while(i<5){
System.out.println("sterling institute");
i++;
}
System.out.println("hello");

int a=0;

while(a<5){
System.out.println("sterling institute");
a++;
}
System.out.println("hello");

int b=0;

while(b<5){
System.out.println("sterling institute");
b++;
}
System.out.println("hello");

int c=0;

while(c<5){
System.out.println("sterling institute");
c++;
}
System.out.println("hello");

int d=0;

while(d<5){
System.out.println("sterling institute");
d++;
}
}
}